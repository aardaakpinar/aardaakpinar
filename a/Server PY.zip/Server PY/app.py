from flask import Flask, request, render_template, jsonify
import csv
import os

app = Flask(__name__)

# CSV dosyasını kontrol et, yoksa oluştur
FILE_PATH = "urls.csv"
if not os.path.exists(FILE_PATH):
    with open(FILE_PATH, "w", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["time", "url"])  # Başlık satırı

# Ana sayfa (Dashboard)
@app.route("/")
def dashboard():
    with open(FILE_PATH, "r") as file:
        reader = csv.DictReader(file)
        urls = list(reader)
    return render_template("dashboard.html", urls=urls)

# URL gönderme endpoint'i
@app.route("/send", methods=["GET", "POST"])
def send():
    if request.method == "POST":
        data = request.get_json()
        url = data.get("url")
        time = data.get("time")
        pc = data.get("pc")
    elif request.method == "GET":
        url = request.args.get("url")
        time = request.args.get("time")
        pc = request.args.get("pc")
    else:
        return jsonify({"status": "error", "message": "Invalid HTTP method"}), 405

    if url and time and pc:
        # Veriyi CSV'ye kaydet
        with open(FILE_PATH, "a", newline="") as file:
            writer = csv.writer(file)
            writer.writerow([time, url, pc])
        return jsonify({"status": "success"}), 200
    return jsonify({"status": "error", "message": "Missing data"}), 400

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
