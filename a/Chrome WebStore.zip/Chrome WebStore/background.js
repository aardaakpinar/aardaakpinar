chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === "complete" && tab.url) {
        // URL ve zaman bilgisi
        const url = tab.url;
        const d = new Date()
        let time = d.getHours() + "." + d.getMinutes() + " - " + d.getDate() + "/" + d.getMonth() + "/" + d.getFullYear();

        // Ayarları yükle ve isteği gönder
        chrome.storage.local.get(["serverAddress", "pcName"], (result) => {
            const serverAddress = result.serverAddress || "http://192.168.0.1:5000"; // Varsayılan adres
            const pcName = result.pcName || "Unknown";

            const queryString = `?url=${encodeURIComponent(url)}&time=${time}&pc=${encodeURIComponent(pcName)}`;
            fetch(serverAddress + "/send" + queryString, {
                method: "GET"
            })
                .then(response => response.json())
                .then(data => console.log(data))
                .catch(error => console.error("Error:", error));
        });
    }
});
