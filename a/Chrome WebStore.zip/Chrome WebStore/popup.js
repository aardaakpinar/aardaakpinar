document.addEventListener("DOMContentLoaded", () => {
    const serverInput = document.getElementById("server");
    const pcNameInput = document.getElementById("pcName");
    const saveButton = document.getElementById("saveSettings");

    // Ayarları yükle
    chrome.storage.local.get(["serverAddress", "pcName"], (result) => {
        if (result.serverAddress) serverInput.value = result.serverAddress;
        if (result.pcName) pcNameInput.value = result.pcName;
    });

    // Ayarları kaydet
    saveButton.addEventListener("click", () => {
        const serverAddress = serverInput.value.trim();
        const pcName = pcNameInput.value.trim();

        chrome.storage.local.set({ serverAddress, pcName }, () => {
            alert("Ayarlar kaydedildi!");
        });
    });
});
